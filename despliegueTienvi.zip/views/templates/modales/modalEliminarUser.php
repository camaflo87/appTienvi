<div id="myModal" class="modal">
    <div class="modal-content">
        <div class="modal-title">¿Estás seguro de realizar esta acción?</div>
        <div class="modal-options">
            <button class="modal-btn btn-yes" id="btnYes">SÍ</button>
            <button class="modal-btn btn-no" id="btnNo">NO</button>
        </div>
    </div>
</div>