<?php

require_once __DIR__ . '/../includes/app.php';

use MVC\Router;
use Controllers\ApiController;
use Controllers\AuthController;
use Controllers\adminController;
use Controllers\indexController;
use Controllers\AbonosController;
use Controllers\CreditosController;

$router = new Router();

// Pagina principal
$router->get('/', [IndexController::class, 'consultaClientes']); // Terminado </

// Login
$router->get('/login', [AuthController::class, 'login']); // Terminado </
$router->post('/login', [AuthController::class, 'login']); // Terminado </
$router->post('/logout', [AuthController::class, 'logout']); // Terminado </

// Crear Cuenta
$router->get('/registro', [AuthController::class, 'registroPersona']); // Terminado
$router->post('/registro', [AuthController::class, 'registroPersona']); //Terminado
$router->get('/mensaje', [AuthController::class, 'mensaje']); // Terminado

// Formulario consultar usuario
$router->get('/modificar', [AuthController::class, 'modificar_usuario']); // Terminado </
$router->post('/modificar', [AuthController::class, 'modificar_usuario']); // Terminado </

// Informe credito
$router->get('/informe-credito', [AuthController::class, 'informe_credito']); // Terminado </

// Zona de administración
$router->get('/administracion', [AdminController::class, 'index']); // Terminado </
$router->get('/administracion_consultas', [AdminController::class, 'consulta_personalizada']); // Terminado </

// Administración de creditos
$router->get('/creditos_informes', [CreditosController::class, 'informe_deudores']); // Terminado </
$router->post('/informePdf', [CreditosController::class, 'informe_pdf']); // Terminado </
$router->get('/creditos_individuales', [CreditosController::class, 'credito_persona']); // Terminado

// Administración abonos
$router->get('/abonos_individuales', [AbonosController::class, 'abonos_persona']); // Terminado </


// Api Controller
$router->post('/api/eliminar_usuario', [ApiController::class, 'eliminar_usuario']); // Adm. eliminación de usuarios </
$router->post('/api/actualizar_bloqueos', [ApiController::class, 'actualiza_bloqueo']); // Adm. bloqueo de clientes </
$router->post('/api/consulta_nombre', [ApiController::class, 'nombre_usuario']); // Adm. Consulta cliente </
$router->post('/api/agregar_credito', [ApiController::class, 'ingresar_credito']); // Adm. Ingresar credito </
$router->post('/api/consulta_bloqueo', [ApiController::class, 'consultaBloqueo']); // Adm. Consulta de usuarios bloqueados </
$router->post('/api/consulta_deuda', [ApiController::class, 'consultaDeuda']); // Adm. Consulta deuda usuario </
$router->post('/api/agregar_abono', [ApiController::class, 'ingresar_abono']); // Registrar abono </
$router->get('/api/informe_deudores', [ApiController::class, 'informe_deudores']); // Informe deudores </
$router->post('/api/modificar_credito', [ApiController::class, 'modificarCredito']); // Adm. Modificar el credito de un usuario </
$router->post('/api/eliminar_credito', [ApiController::class, 'eliminarCredito']); // Adm. Elimina un registro de tipo credito </
$router->post('/api/eliminar_abono', [ApiController::class, 'eliminarAbono']); // Adm. Elimina un registro de tipo abono </
$router->post('/api/modificar_abono', [ApiController::class, 'modificarAbono']); // Adm. Modifica el abono de un usuario </
$router->get('/api/filtro', [ApiController::class, 'filtroPersonas']); // Filtra los usuarios para busquedad
$router->post('/api/credito_usuario', [ApiController::class, 'registro_credito']); // Adm. Consulta el credio del usuario en el index




$router->comprobarRutas();
